# 云贝

云贝是一个面向普通 Codex 用户的 macOS 小工具。启动后会先出现 **云贝账号登录**：用户必须先登录云贝账号，登录成功后才能进入 **凭证管理** 和 **历史修复**。

服务器由云贝自动连接，界面只显示“服务器网址”，用户不需要填写或修改地址。

登录后，普通用户先在 **凭证管理** 粘贴 OpenAI 兼容 API，然后点击 **启动 Codex** 即可开始使用；老用户需要找回本机历史时，再进入 **历史修复** 页面按步骤处理。

底层 CLI 仍叫 `codex-history-unifier`，它负责把本机已经存在的 Codex 历史修复到当前 Codex profile 可见，不论当前登录的是哪个账号。

The history repair workflow remains intentionally focused on **local history visibility**:

- It scans `sessions/**/rollout-*.jsonl` and `archived_sessions/**/rollout-*.jsonl`.
- It can copy missing/newer sessions from discovered or manual source `CODEX_HOME` directories into the target `CODEX_HOME`.
- It discovers `~/.codex`, `~/.codex-*`, `~/.codex_*`, and Cockpit Tools Codex instance directories by default.
- It rewrites rollout `session_meta.payload.model_provider` to match the target profile's `config.toml` provider, defaulting to `openai`.
- It upserts missing `session_index.jsonl` records.
- It updates existing compatible `state_5.sqlite.threads` rows.
- It never reads or prints `auth.json` tokens.

## Install for local development

```bash
cd /Users/ethan/Documents/Codex/2026-06-04/codex-history-unifier
PYTHONPATH=src python3 -m codex_history_unifier.cli --help
```

Optional editable install:

```bash
python3 -m pip install -e .
```


## macOS App

Build the clickable app bundle:

```bash
cd /Users/ethan/Documents/Codex/2026-06-04/codex-history-unifier
python3 scripts/build_macos_app.py
```

Then open:

```bash
open "dist/云贝.app"
```

启动流程：

1. 打开云贝后，先输入云贝账号和密码。
2. “服务器网址”由云贝自动连接，用户不需要填写或修改。
3. 点击 **登录云贝**。
4. 如果账号启用了安全验证，云贝会提示继续输入验证码或备用码。
5. 登录成功后进入工具页。

App 登录后只有两个页面：

1. **凭证管理**：默认打开。先粘贴服务商 API 或 curl，保存后在凭证池点击 **启动 Codex**。云贝会自动备份并写入目标 `CODEX_HOME` 的 `auth.json` / `config.toml`，然后打开或重启 Codex。
2. **历史修复**：给换过账号、换过 provider、迁移过 `CODEX_HOME` 的老用户使用。它只修复本机已经存在的历史可见性，不会从云端下载历史。

云贝登录状态保存在本机应用支持目录。点击 **退出登录** 会清除本机登录状态，下次打开需要重新登录。

Logs go to:

```text
~/Library/Logs/云贝/app.log
```

## Credential management page

The macOS app opens on the **凭证管理** tab first. It is organized as a simple two-step flow: paste API, then start Codex. A full-width credential pool and bottom settings are available below for the target `CODEX_HOME` plus logs.

The credential page can manage two credential kinds:

1. **Codex AUTH/OAuth credentials** created by **Gpt auth登录**. The tool runs the Codex login flow in an isolated `CODEX_HOME`, then automatically saves the generated `auth.json` as a credential.
2. **Third-party OpenAI-compatible API credentials** imported from pasted `curl` text, for example a request that contains:

- `--url https://provider.example/v1/chat/completions` or `--url https://provider.example/v1/responses`
- `Authorization: Bearer ...`
- a JSON body with an optional `model` field

Saved credentials are stored locally at:

```text
~/.codex-history-unifier/codex_credentials.json
```

When you click **启动 Codex** on a saved credential, the tool creates the target `CODEX_HOME` if needed, backs up existing `auth.json` and `config.toml` under `<CODEX_HOME>/backups/credential-launch-*`, writes the selected credential into the target, and then restarts/opens Codex.

- For a **third-party API** credential, it writes API-key `auth.json` plus this tool's managed provider block in `config.toml`.
- For a **Codex AUTH** credential, it restores the saved `auth.json`, removes this tool's managed third-party provider block from `config.toml`, and switches `model_provider` back to `openai` while preserving unrelated config sections.

A default initial `CODEX_HOME` does not need to be OAuth-logged-in before using a third-party API credential. Third-party API credentials are provider/API-key configuration, not a ChatGPT/Codex OAuth account login.

Credential liveness is refreshed automatically when the user clicks **刷新**. Third-party API credentials are checked by sending a minimal non-streaming request to the stored endpoint with the saved model and Bearer token. Codex AUTH/OAuth credentials are checked by writing the saved `auth.json` into a temporary `CODEX_HOME` and running `codex login status`. The UI shows `存活` in green, `已失效` in red, and `未检测` in gray before a check has run.

Credential UI output and CLI JSON summaries mask API keys and OAuth tokens. The credential store itself must contain the full secret material so the launcher can write Codex configuration. The original history repair commands still do not read or print `auth.json` tokens; credential files are touched only from the explicit credential commands/page.

CLI examples:

```bash
# Run GPT/Codex auth login and save the generated AUTH credential
PYTHONPATH=src python3 -m codex_history_unifier.cli credentials login-auth --name "Gpt auth登录" --json

# Save a pasted curl/API snippet
pbpaste | PYTHONPATH=src python3 -m codex_history_unifier.cli credentials import-api --from-stdin --json

# List saved credentials with masked keys/tokens
PYTHONPATH=src python3 -m codex_history_unifier.cli credentials list --json

# Refresh liveness for every saved credential
PYTHONPATH=src python3 -m codex_history_unifier.cli credentials validate-all --timeout 10 --json

# Write one credential into a target CODEX_HOME without restarting Codex
PYTHONPATH=src python3 -m codex_history_unifier.cli credentials launch <credential-id> --codex-home ~/.codex --no-restart --json
```

## Common usage

Preview current target and discovered sources:

```bash
PYTHONPATH=src python3 -m codex_history_unifier.cli scan
```

Diagnose what needs to change for full local visibility:

```bash
PYTHONPATH=src python3 -m codex_history_unifier.cli doctor
```

Repair only the current target `CODEX_HOME` without copying from other sources:

```bash
PYTHONPATH=src python3 -m codex_history_unifier.cli repair --apply
```

Unify all discovered Cockpit Tools Codex instances and any manual source into the current target:

```bash
PYTHONPATH=src python3 -m codex_history_unifier.cli unify --source /path/to/other/CODEX_HOME --apply
```

Use a specific target:

```bash
PYTHONPATH=src python3 -m codex_history_unifier.cli unify --codex-home ~/.codex --apply
```

## Safety model

- Dry-run is the default for `repair` and `unify`.
- Add `--apply` to actually modify files.
- Applying creates a backup under `<CODEX_HOME>/backups/history-unifier-YYYYMMDD-HHMMSS` unless `--no-backup` is used.
- The tool does not fetch cloud history. "Full history" means local history already present on this machine or under explicitly provided source directories.
- History repair commands do not parse or print `auth.json`. The supplemental credential management page writes `auth.json` only when the user explicitly starts a saved credential, and command/UI summaries mask API keys and OAuth tokens.

## Testing

```bash
PYTHONPATH=src python3 -m unittest discover -s tests -v
```
