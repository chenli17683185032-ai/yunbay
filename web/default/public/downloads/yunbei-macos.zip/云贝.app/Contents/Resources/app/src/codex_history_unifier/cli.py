from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Iterable, List, Optional


from .credentials import (
    add_api_credential,
    add_api_credential_from_curl,
    delete_credential,
    import_codex_auth_credential,
    login_gpt_auth_credential,
    launch_credential,
    list_credentials,
    validate_all_credentials,
    validate_credential,
)

from .core import (
    ApplyOptions,
    ApplySummary,
    build_plan,
    collect_history_sources,
    crack_status,
    plan_summary,
    repair_history,
    resolve_codex_home,
    run_crack_dialog,
    scan_history,
    start_crack_mode,
    stop_crack_mode,
    unify_history,
    validate_crack_mode,
)


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if is_dataclass(value):
        return asdict(value)
    return str(value)


def _print_json(payload: Any) -> None:
    print(json.dumps(payload, indent=2, ensure_ascii=False, default=_json_default))


def _summary_payload(summary: ApplySummary) -> dict:
    return {
        "target_root": str(summary.target_root),
        "target_provider": summary.target_provider,
        "dry_run": summary.dry_run,
        "copied_files": summary.copied_files,
        "rewritten_rollouts": summary.rewritten_rollouts,
        "index_entries_added": summary.index_entries_added,
        "sqlite_rows_updated": summary.sqlite_rows_updated,
        "backup_dir": str(summary.backup_dir) if summary.backup_dir else None,
    }


def _print_summary(summary: ApplySummary) -> None:
    mode = "DRY-RUN" if summary.dry_run else "APPLIED"
    print(f"Codex History Unifier: {mode}")
    print(f"Target CODEX_HOME: {summary.target_root}")
    print(f"Target provider: {summary.target_provider}")
    print(f"Copied rollout files: {summary.copied_files}")
    print(f"Rewritten rollout files: {summary.rewritten_rollouts}")
    print(f"Added session_index entries: {summary.index_entries_added}")
    print(f"Updated SQLite rows: {summary.sqlite_rows_updated}")
    if summary.backup_dir:
        print(f"Backup: {summary.backup_dir}")
    if summary.dry_run:
        print("No files were changed. Re-run with --apply to write changes.")


def _paths(values: Optional[Iterable[str]]) -> List[Path]:
    return [Path(item).expanduser() for item in (values or [])]


def _target(args: argparse.Namespace) -> Path:
    return resolve_codex_home(args.codex_home)


def cmd_scan(args: argparse.Namespace) -> int:
    target = _target(args)
    sources = collect_history_sources(
        target,
        _paths(args.source),
        discover_cockpit=not args.no_cockpit,
    )
    scans = [scan_history(source) for source in sources]
    payload = {
        "target": asdict(scan_history(target)),
        "sources": [asdict(item) for item in scans],
    }
    if args.json:
        _print_json(payload)
        return 0
    print(f"Target CODEX_HOME: {target}")
    for item in scans:
        print(f"- {item.root}")
        print(f"  rollout files: {item.rollout_count}")
        print(f"  unique sessions: {item.unique_session_count}")
        print(f"  invalid rollout files: {item.invalid_rollout_count}")
        if item.provider_counts:
            providers = ", ".join(f"{key}={value}" for key, value in sorted(item.provider_counts.items()))
            print(f"  providers: {providers}")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    target = _target(args)
    sources = collect_history_sources(
        target,
        _paths(args.source),
        discover_cockpit=not args.no_cockpit,
    )
    plan = build_plan(target, sources)
    payload = plan_summary(plan)
    if args.json:
        _print_json(payload)
        return 0
    print("Codex History Visibility Doctor")
    print(f"Target CODEX_HOME: {payload['target_root']}")
    print(f"Target provider: {payload['target_provider']}")
    print(f"Sources: {len(payload['source_roots'])}")
    print(f"Files missing/newer in target: {payload['copy_files']}")
    print(f"Rollouts needing provider rewrite: {payload['rewrite_rollouts']}")
    print(f"Missing session_index entries: {payload['upsert_index_entries']}")
    print(f"SQLite rows needing update: {payload['sqlite_rows_to_update']}")
    return 0


def cmd_repair(args: argparse.Namespace) -> int:
    target = _target(args)
    summary = repair_history(target, ApplyOptions(apply=args.apply, backup=not args.no_backup))
    if args.json:
        _print_json(_summary_payload(summary))
    else:
        _print_summary(summary)
    return 0


def cmd_unify(args: argparse.Namespace) -> int:
    target = _target(args)
    sources = collect_history_sources(
        target,
        _paths(args.source),
        discover_cockpit=not args.no_cockpit,
    )
    summary = unify_history(target, sources, ApplyOptions(apply=args.apply, backup=not args.no_backup))
    if args.json:
        _print_json(_summary_payload(summary))
    else:
        _print_summary(summary)
    return 0


def cmd_crack(args: argparse.Namespace) -> int:
    target = _target(args)
    if args.crack_command == "start":
        summary = start_crack_mode(target)
    elif args.crack_command == "stop":
        summary = stop_crack_mode(target)
    elif args.crack_command == "status":
        summary = crack_status(target)
    elif args.crack_command == "validate":
        summary = validate_crack_mode(target, codex_bin=args.codex_bin)
    elif args.crack_command == "dialog":
        summary = run_crack_dialog(target, prompt=args.message, codex_bin=args.codex_bin)
    else:
        raise ValueError(f"unknown crack command: {args.crack_command}")

    payload = asdict(summary)
    if args.json:
        _print_json(payload)
    else:
        print(summary.message)
        print(f"Target CODEX_HOME: {summary.target_root}")
        print(f"Config path correct: {summary.config_path_correct}")
        print(f"Instruction file exists: {summary.instruction_exists}")
        if summary.codex_response:
            print()
            print(summary.codex_response)
    return 0



def _credential_store_path(args: argparse.Namespace) -> Optional[Path]:
    raw = getattr(args, "store_path", None)
    return Path(raw).expanduser() if raw else None


def _print_credentials_payload(args: argparse.Namespace, payload: Any) -> None:
    if args.json:
        _print_json(payload)
        return
    if isinstance(payload, list):
        if not payload:
            print("No Codex credentials saved.")
            return
        for item in payload:
            print(f"- {item['name']} ({item['id']})")
            print(f"  Type: {item.get('credential_type_label') or item.get('kind') or '-'}")
            if item.get("kind") == "codex_auth":
                print(f"  Auth Mode: {item.get('auth_mode') or 'unknown'}")
            else:
                print(f"  Base URL: {item.get('api_base_url') or '-'}")
                print(f"  Wire API: {item.get('wire_api') or '-'}")
                print(f"  API Key: {item.get('api_key_masked') or '-'}")
        return
    if isinstance(payload, dict) and "message" in payload:
        print(payload["message"])
        return
    print(json.dumps(payload, indent=2, ensure_ascii=False, default=_json_default))


def cmd_credentials(args: argparse.Namespace) -> int:
    store_path = _credential_store_path(args)
    if args.credentials_command == "list":
        payload = list_credentials(store_path=store_path)
    elif args.credentials_command == "import-api":
        if args.from_stdin:
            raw = sys.stdin.read()
        elif args.file:
            raw = Path(args.file).expanduser().read_text(encoding="utf-8")
        else:
            raise ValueError("import-api requires --from-stdin or --file")
        credential = add_api_credential_from_curl(raw, store_path=store_path)
        payload = credential.to_summary_dict()
    elif args.credentials_command == "import-auth":
        credential = import_codex_auth_credential(
            resolve_codex_home(args.codex_home),
            store_path=store_path,
            name=args.name,
        )
        payload = credential.to_summary_dict()
    elif args.credentials_command == "login-auth":
        payload = login_gpt_auth_credential(
            codex_bin=args.codex_bin,
            login_root=Path(args.login_root).expanduser() if args.login_root else None,
            store_path=store_path,
            name=args.name,
            device_auth=args.device_auth,
            timeout=args.timeout,
        )
    elif args.credentials_command == "add-api":
        credential = add_api_credential(
            name=args.name,
            api_key=args.api_key,
            api_base_url=args.base_url,
            api_endpoint=args.endpoint,
            wire_api=args.wire_api,
            default_model=args.model,
            supports_text=not args.no_text,
            supports_image=args.supports_image,
            store_path=store_path,
        )
        payload = credential.to_summary_dict()
    elif args.credentials_command == "delete":
        payload = delete_credential(args.credential_id, store_path=store_path)
    elif args.credentials_command == "launch":
        payload = launch_credential(
            args.credential_id,
            codex_home=resolve_codex_home(args.codex_home),
            store_path=store_path,
            restart=not args.no_restart,
        )
    elif args.credentials_command == "validate":
        payload = validate_credential(
            args.credential_id,
            store_path=store_path,
            timeout=args.timeout,
            codex_bin=args.codex_bin,
        )
    elif args.credentials_command == "validate-all":
        payload = validate_all_credentials(
            store_path=store_path,
            timeout=args.timeout,
            codex_bin=args.codex_bin,
        )
    else:
        raise ValueError(f"unknown credentials command: {args.credentials_command}")

    _print_credentials_payload(args, payload)
    return 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="codex-history-unifier",
        description="Unify and repair local Codex history so it stays visible across logged-in accounts.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    def add_common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--codex-home", help="Target CODEX_HOME. Defaults to $CODEX_HOME or ~/.codex.")
        p.add_argument("--source", action="append", default=[], help="Additional source CODEX_HOME to scan. Can be repeated.")
        p.add_argument("--no-cockpit", action="store_true", help="Do not discover Cockpit Tools Codex instances.")
        p.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    scan = sub.add_parser("scan", help="Scan target and discovered sources without planning changes.")
    add_common(scan)
    scan.set_defaults(func=cmd_scan)

    doctor = sub.add_parser("doctor", help="Report what would be needed to make all local history visible.")
    add_common(doctor)
    doctor.set_defaults(func=cmd_doctor)

    repair = sub.add_parser("repair", help="Repair target CODEX_HOME visibility without copying from other sources.")
    repair.add_argument("--codex-home", help="Target CODEX_HOME. Defaults to $CODEX_HOME or ~/.codex.")
    repair.add_argument("--apply", action="store_true", help="Actually modify files. Without this, dry-run only.")
    repair.add_argument("--no-backup", action="store_true", help="Skip backup creation when applying changes.")
    repair.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    repair.set_defaults(func=cmd_repair)

    unify = sub.add_parser("unify", help="Copy missing/newer local history into target, then repair visibility.")
    add_common(unify)
    unify.add_argument("--apply", action="store_true", help="Actually modify files. Without this, dry-run only.")
    unify.add_argument("--no-backup", action="store_true", help="Skip backup creation when applying changes.")
    unify.set_defaults(func=cmd_unify)

    crack = sub.add_parser("crack", help="Manage the local CTF crack mode instruction hook.")
    crack.add_argument("crack_command", choices=["start", "stop", "status", "validate", "dialog"], help="Crack mode action.")
    crack.add_argument("--codex-home", help="Target CODEX_HOME. Defaults to $CODEX_HOME or ~/.codex.")
    crack.add_argument("--message", help="One-shot crack dialog message. Defaults to the built-in CTF validation text.")
    crack.add_argument("--codex-bin", default="codex", help=argparse.SUPPRESS)
    crack.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    crack.set_defaults(func=cmd_crack)


    credentials = sub.add_parser("credentials", help="Manage supplemental Codex credentials.")
    credentials_sub = credentials.add_subparsers(dest="credentials_command", required=True)

    def add_credentials_common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--store-path", help="Credential store path. Defaults to ~/.codex-history-unifier/codex_credentials.json.")
        p.add_argument("--json", action="store_true", help="Print machine-readable JSON.")

    credentials_list = credentials_sub.add_parser("list", help="List saved Codex credentials.")
    add_credentials_common(credentials_list)
    credentials_list.set_defaults(func=cmd_credentials)

    credentials_import_auth = credentials_sub.add_parser("import-auth", help="Import the current Codex AUTH/OAuth credential from CODEX_HOME.")
    credentials_import_auth.add_argument("--codex-home", help="Source CODEX_HOME. Defaults to $CODEX_HOME or ~/.codex.")
    credentials_import_auth.add_argument("--name", help="Credential display name. Defaults to Codex AUTH.")
    add_credentials_common(credentials_import_auth)
    credentials_import_auth.set_defaults(func=cmd_credentials)

    credentials_login_auth = credentials_sub.add_parser("login-auth", help="Run GPT/Codex auth login and save the generated AUTH credential.")
    credentials_login_auth.add_argument("--codex-bin", default="codex", help="Codex CLI executable used for login.")
    credentials_login_auth.add_argument("--login-root", help="Isolated CODEX_HOME used for the login flow.")
    credentials_login_auth.add_argument("--name", help="Credential display name. Defaults to Gpt auth登录.")
    credentials_login_auth.add_argument("--device-auth", action="store_true", help="Use Codex device-auth login flow.")
    credentials_login_auth.add_argument("--timeout", type=float, help="Login timeout in seconds.")
    add_credentials_common(credentials_login_auth)
    credentials_login_auth.set_defaults(func=cmd_credentials)

    credentials_import = credentials_sub.add_parser("import-api", help="Import a third-party API credential from pasted curl text.")
    credentials_import.add_argument("--from-stdin", action="store_true", help="Read pasted API/curl text from stdin.")
    credentials_import.add_argument("--file", help="Read pasted API/curl text from a UTF-8 file.")
    add_credentials_common(credentials_import)
    credentials_import.set_defaults(func=cmd_credentials)

    credentials_add = credentials_sub.add_parser("add-api", help="Add a third-party API credential from explicit fields.")
    credentials_add.add_argument("--name", required=True, help="Credential display name.")
    credentials_add.add_argument("--api-key", required=True, help="Bearer/API key. Hidden in command output.")
    credentials_add.add_argument("--base-url", required=True, help="Provider Base URL or endpoint URL.")
    credentials_add.add_argument("--endpoint", help="Original endpoint URL, optional.")
    credentials_add.add_argument("--wire-api", choices=["responses", "chat_completions"], help="Provider protocol. Inferred from URL when omitted.")
    credentials_add.add_argument("--model", help="Default model written into config.toml.")
    credentials_add.add_argument("--supports-image", action="store_true", help="Mark this credential as image-capable.")
    credentials_add.add_argument("--no-text", action="store_true", help="Mark this credential as not text-capable.")
    add_credentials_common(credentials_add)
    credentials_add.set_defaults(func=cmd_credentials)

    credentials_delete = credentials_sub.add_parser("delete", help="Delete a saved credential.")
    credentials_delete.add_argument("credential_id")
    add_credentials_common(credentials_delete)
    credentials_delete.set_defaults(func=cmd_credentials)

    credentials_launch = credentials_sub.add_parser("launch", help="Write a credential into CODEX_HOME and launch Codex.")
    credentials_launch.add_argument("credential_id")
    credentials_launch.add_argument("--codex-home", help="Target CODEX_HOME. Defaults to $CODEX_HOME or ~/.codex.")
    credentials_launch.add_argument("--no-restart", action="store_true", help="Write config only; do not restart/open Codex App.")
    add_credentials_common(credentials_launch)
    credentials_launch.set_defaults(func=cmd_credentials)

    credentials_validate = credentials_sub.add_parser("validate", help="Check whether a third-party API credential is alive.")
    credentials_validate.add_argument("credential_id")
    credentials_validate.add_argument("--timeout", type=float, default=10, help="Validation request timeout in seconds.")
    credentials_validate.add_argument("--codex-bin", default="codex", help="Codex CLI executable used for AUTH credential validation.")
    add_credentials_common(credentials_validate)
    credentials_validate.set_defaults(func=cmd_credentials)

    credentials_validate_all = credentials_sub.add_parser("validate-all", help="Refresh credentials and validate whether they are alive.")
    credentials_validate_all.add_argument("--timeout", type=float, default=10, help="Per-credential validation timeout in seconds.")
    credentials_validate_all.add_argument("--codex-bin", default="codex", help="Codex CLI executable used for AUTH credential validation.")
    add_credentials_common(credentials_validate_all)
    credentials_validate_all.set_defaults(func=cmd_credentials)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
