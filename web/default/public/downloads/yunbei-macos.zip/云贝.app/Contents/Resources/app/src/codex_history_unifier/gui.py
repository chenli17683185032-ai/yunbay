from __future__ import annotations

import json
import subprocess
import threading
import traceback
from dataclasses import asdict
from pathlib import Path
from typing import Callable, List, Optional

import tkinter as tk
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText

from .core import (
    ApplyOptions,
    build_plan,
    collect_history_sources,
    plan_summary,
    repair_history,
    resolve_codex_home,
    scan_history,
    unify_history,
)


def format_scan_report(target: Path, sources: List[Path]) -> str:
    lines = ["Codex History Unifier - Scan", "", f"Target CODEX_HOME: {target}", ""]
    if not sources:
        lines.append("No history sources found.")
        return "\n".join(lines)
    for source in sources:
        scan = scan_history(source)
        lines.append(f"Source: {scan.root}")
        lines.append(f"  rollout files: {scan.rollout_count}")
        lines.append(f"  unique sessions: {scan.unique_session_count}")
        lines.append(f"  invalid rollout files: {scan.invalid_rollout_count}")
        if scan.provider_counts:
            providers = ", ".join(f"{key}={value}" for key, value in sorted(scan.provider_counts.items()))
            lines.append(f"  providers: {providers}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def format_doctor_report(target: Path, sources: List[Path]) -> str:
    plan = build_plan(target, sources)
    summary = plan_summary(plan)
    return (
        "Codex History Unifier - Doctor\n\n"
        f"Target CODEX_HOME: {summary['target_root']}\n"
        f"Target provider: {summary['target_provider']}\n"
        f"Sources: {len(summary['source_roots'])}\n"
        f"Files missing/newer in target: {summary['copy_files']}\n"
        f"Rollouts needing provider rewrite: {summary['rewrite_rollouts']}\n"
        f"Missing session_index entries: {summary['upsert_index_entries']}\n"
        f"SQLite rows needing update: {summary['sqlite_rows_to_update']}\n"
    )


def format_apply_summary(title: str, summary) -> str:
    payload = asdict(summary)
    return (
        f"Codex History Unifier - {title}\n\n"
        f"Target CODEX_HOME: {payload['target_root']}\n"
        f"Target provider: {payload['target_provider']}\n"
        f"Dry run: {payload['dry_run']}\n"
        f"Copied rollout files: {payload['copied_files']}\n"
        f"Rewritten rollout files: {payload['rewritten_rollouts']}\n"
        f"Added session_index entries: {payload['index_entries_added']}\n"
        f"Updated SQLite rows: {payload['sqlite_rows_updated']}\n"
        f"Backup: {payload['backup_dir']}\n"
    )


class CodexHistoryUnifierApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Codex History Unifier")
        self.root.geometry("900x650")
        self._build_ui()

    def _build_ui(self) -> None:
        frame = ttk.Frame(self.root, padding=12)
        frame.pack(fill=tk.BOTH, expand=True)

        title = ttk.Label(frame, text="Codex History Unifier", font=("Helvetica", 18, "bold"))
        title.pack(anchor=tk.W)
        subtitle = ttk.Label(
            frame,
            text="让当前 Codex App 在任意登录账号下尽量看到本机全量历史。默认 dry-run；Apply 会先备份。",
        )
        subtitle.pack(anchor=tk.W, pady=(4, 12))

        target_row = ttk.Frame(frame)
        target_row.pack(fill=tk.X, pady=4)
        ttk.Label(target_row, text="Target CODEX_HOME:", width=18).pack(side=tk.LEFT)
        self.target_var = tk.StringVar(value=str(resolve_codex_home()))
        ttk.Entry(target_row, textvariable=self.target_var).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(target_row, text="Open", command=self.open_target_folder).pack(side=tk.LEFT, padx=(8, 0))

        source_label = ttk.Label(frame, text="Extra source CODEX_HOME paths (one per line, optional):")
        source_label.pack(anchor=tk.W, pady=(8, 2))
        self.sources_text = tk.Text(frame, height=3)
        self.sources_text.pack(fill=tk.X)

        options = ttk.Frame(frame)
        options.pack(fill=tk.X, pady=8)
        self.discover_cockpit_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            options,
            text="Discover Cockpit Tools Codex instances; ~/.codex-* sibling dirs are always scanned",
            variable=self.discover_cockpit_var,
        ).pack(side=tk.LEFT)

        buttons = ttk.Frame(frame)
        buttons.pack(fill=tk.X, pady=(4, 8))
        ttk.Button(buttons, text="Scan", command=lambda: self.run_async(self.scan)).pack(side=tk.LEFT, padx=(0, 6))
        ttk.Button(buttons, text="Doctor", command=lambda: self.run_async(self.doctor)).pack(side=tk.LEFT, padx=6)
        ttk.Button(buttons, text="Unify Dry Run", command=lambda: self.run_async(self.unify_dry_run)).pack(side=tk.LEFT, padx=6)
        ttk.Button(buttons, text="Unify Apply", command=lambda: self.run_async(self.unify_apply)).pack(side=tk.LEFT, padx=6)
        ttk.Button(buttons, text="Repair Apply Current Only", command=lambda: self.run_async(self.repair_apply)).pack(side=tk.LEFT, padx=6)

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(frame, textvariable=self.status_var).pack(anchor=tk.W, pady=(0, 4))
        self.output = ScrolledText(frame, wrap=tk.WORD, height=24)
        self.output.pack(fill=tk.BOTH, expand=True)

    def _target(self) -> Path:
        return Path(self.target_var.get()).expanduser().resolve()

    def _manual_sources(self) -> List[Path]:
        raw = self.sources_text.get("1.0", tk.END).splitlines()
        return [Path(line.strip()).expanduser() for line in raw if line.strip()]

    def _sources(self) -> List[Path]:
        return collect_history_sources(
            self._target(),
            self._manual_sources(),
            discover_cockpit=bool(self.discover_cockpit_var.get()),
        )

    def run_async(self, func: Callable[[], str]) -> None:
        self.status_var.set("Running...")
        self.output.delete("1.0", tk.END)

        def worker() -> None:
            try:
                text = func()
                self.root.after(0, lambda: self.show_result(text))
            except Exception:
                error = traceback.format_exc()
                self.root.after(0, lambda: self.show_error(error))

        threading.Thread(target=worker, daemon=True).start()

    def show_result(self, text: str) -> None:
        self.output.insert(tk.END, text)
        self.status_var.set("Ready")

    def show_error(self, text: str) -> None:
        self.output.insert(tk.END, text)
        self.status_var.set("Error")
        messagebox.showerror("Codex History Unifier", "Operation failed. See output for details.")

    def scan(self) -> str:
        return format_scan_report(self._target(), self._sources())

    def doctor(self) -> str:
        return format_doctor_report(self._target(), self._sources())

    def unify_dry_run(self) -> str:
        summary = unify_history(self._target(), self._sources(), ApplyOptions(apply=False, backup=True))
        return format_apply_summary("Unify Dry Run", summary)

    def unify_apply(self) -> str:
        summary = unify_history(self._target(), self._sources(), ApplyOptions(apply=True, backup=True))
        return format_apply_summary("Unify Apply", summary)

    def repair_apply(self) -> str:
        summary = repair_history(self._target(), ApplyOptions(apply=True, backup=True))
        return format_apply_summary("Repair Apply", summary)

    def open_target_folder(self) -> None:
        target = self._target()
        target.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(["open", str(target)])


def main() -> int:
    root = tk.Tk()
    CodexHistoryUnifierApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
