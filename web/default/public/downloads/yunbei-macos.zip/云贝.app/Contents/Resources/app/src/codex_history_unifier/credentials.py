from __future__ import annotations

import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import tempfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse, urlunparse
from urllib.request import Request, urlopen

DEFAULT_STORE_PATH = Path.home() / ".codex-history-unifier" / "codex_credentials.json"
STORE_VERSION = 1
API_KEY_AUTH_MODE = "apikey"
MANAGED_PROVIDER_ID = "codex_history_unifier_api"
DEFAULT_WIRE_API = "responses"
CHAT_COMPLETIONS_WIRE_API = "chat_completions"
LIVENESS_UNKNOWN = "unknown"
LIVENESS_ALIVE = "alive"
LIVENESS_DEAD = "dead"


class CredentialError(RuntimeError):
    pass


@dataclass(frozen=True)
class ApiCredentialDraft:
    name: str
    api_key: str
    api_base_url: str
    api_endpoint: Optional[str]
    wire_api: str
    default_model: Optional[str]
    supports_text: bool = True
    supports_image: bool = False


@dataclass
class CodexCredential:
    id: str
    name: str
    kind: str
    api_key: str = ""
    api_base_url: str = ""
    api_endpoint: Optional[str] = None
    wire_api: str = DEFAULT_WIRE_API
    default_model: Optional[str] = None
    supports_text: bool = True
    supports_image: bool = False
    created_at: str = ""
    last_used_at: Optional[str] = None
    auth_json: Optional[Dict[str, Any]] = None
    config_toml: Optional[str] = None
    auth_mode: Optional[str] = None
    source_codex_home: Optional[str] = None
    liveness_status: str = LIVENESS_UNKNOWN
    liveness_checked_at: Optional[str] = None
    liveness_message: Optional[str] = None

    @classmethod
    def from_dict(cls, payload: Dict[str, Any]) -> "CodexCredential":
        kind = str(payload.get("kind") or "api_key")
        fallback_name = "Codex AUTH 凭证" if kind == "codex_auth" else "未命名 API 凭证"
        auth_json = payload.get("auth_json")
        if auth_json is not None and not isinstance(auth_json, dict):
            auth_json = None
        return cls(
            id=str(payload.get("id") or ""),
            name=str(payload.get("name") or fallback_name),
            kind=kind,
            api_key=str(payload.get("api_key") or ""),
            api_base_url=str(payload.get("api_base_url") or ""),
            api_endpoint=normalize_optional_string(payload.get("api_endpoint")),
            wire_api=normalize_wire_api(normalize_optional_string(payload.get("wire_api"))) or DEFAULT_WIRE_API,
            default_model=normalize_optional_string(payload.get("default_model")),
            supports_text=bool(payload.get("supports_text", True)),
            supports_image=bool(payload.get("supports_image", False)),
            created_at=str(payload.get("created_at") or utc_now()),
            last_used_at=normalize_optional_string(payload.get("last_used_at")),
            auth_json=auth_json,
            config_toml=normalize_optional_string(payload.get("config_toml")),
            auth_mode=normalize_optional_string(payload.get("auth_mode")),
            source_codex_home=normalize_optional_string(payload.get("source_codex_home")),
            liveness_status=normalize_liveness_status(payload.get("liveness_status")),
            liveness_checked_at=normalize_optional_string(payload.get("liveness_checked_at")),
            liveness_message=normalize_optional_string(payload.get("liveness_message")),
        )

    def to_store_dict(self) -> Dict[str, Any]:
        return asdict(self)

    def to_summary_dict(self) -> Dict[str, Any]:
        api_key_for_display = self.api_key
        if self.kind == "codex_auth":
            api_key_for_display = _extract_auth_api_key(self.auth_json) or ""
        return {
            "id": self.id,
            "name": self.name,
            "kind": self.kind,
            "credential_type_label": credential_type_label(self.kind),
            "auth_mode": self.auth_mode,
            "api_key_masked": mask_secret(api_key_for_display),
            "api_base_url": self.api_base_url,
            "api_endpoint": self.api_endpoint,
            "wire_api": self.wire_api,
            "default_model": self.default_model,
            "supports_text": self.supports_text,
            "supports_image": self.supports_image,
            "created_at": self.created_at,
            "last_used_at": self.last_used_at,
            "liveness_status": self.liveness_status,
            "liveness_checked_at": self.liveness_checked_at,
            "liveness_message": self.liveness_message,
        }


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def normalize_optional_string(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def normalize_liveness_status(value: Any) -> str:
    text = str(value or "").strip().lower()
    if text in {LIVENESS_UNKNOWN, LIVENESS_ALIVE, LIVENESS_DEAD}:
        return text
    return LIVENESS_UNKNOWN


def mask_secret(value: Optional[str]) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    if len(text) <= 8:
        return "****"
    return f"{text[:6]}…{text[-4:]}"


def credential_type_label(kind: str) -> str:
    if kind == "codex_auth":
        return "Codex AUTH"
    if kind == "api_key":
        return "第三方 API"
    return "未知凭证"


def _extract_auth_api_key(auth_json: Optional[Dict[str, Any]]) -> Optional[str]:
    if not isinstance(auth_json, dict):
        return None
    value = auth_json.get("OPENAI_API_KEY")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _detect_auth_mode(auth_json: Dict[str, Any]) -> str:
    raw_mode = normalize_optional_string(auth_json.get("auth_mode"))
    if raw_mode:
        normalized = raw_mode.lower()
        if normalized in {"oauth", "apikey"}:
            return normalized
    if isinstance(auth_json.get("tokens"), dict):
        return "oauth"
    if _extract_auth_api_key(auth_json):
        return "apikey"
    return "unknown"


def _toml_quote(value: str) -> str:
    return json.dumps(value, ensure_ascii=False)


def normalize_wire_api(value: Optional[str]) -> Optional[str]:
    if not value:
        return None
    normalized = value.strip().lower().replace("-", "_")
    if normalized in {DEFAULT_WIRE_API, CHAT_COMPLETIONS_WIRE_API}:
        return normalized
    if normalized in {"chat", "chat_completions", "chatcompletions"}:
        return CHAT_COMPLETIONS_WIRE_API
    return None


def _canonicalize_url(raw: str) -> str:
    trimmed = raw.strip().strip('"').strip("'").strip().rstrip("/")
    parsed = urlparse(trimmed)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise CredentialError("Base URL 必须是完整的 http:// 或 https:// 地址")
    path = parsed.path.rstrip("/") or ""
    return urlunparse((parsed.scheme, parsed.netloc, path, "", "", ""))


def _derive_base_url_and_wire_api(endpoint_or_base_url: str) -> Tuple[str, str, str]:
    endpoint = _canonicalize_url(endpoint_or_base_url)
    parsed = urlparse(endpoint)
    path = parsed.path.rstrip("/")
    lowered = path.lower()
    wire_api = DEFAULT_WIRE_API
    base_path = path

    if lowered.endswith("/chat/completions"):
        wire_api = CHAT_COMPLETIONS_WIRE_API
        base_path = path[: -len("/chat/completions")].rstrip("/")
    elif lowered.endswith("/responses"):
        wire_api = DEFAULT_WIRE_API
        base_path = path[: -len("/responses")].rstrip("/")

    if not base_path:
        base_path = ""
    base_url = urlunparse((parsed.scheme, parsed.netloc, base_path, "", "", "")).rstrip("/")
    return base_url, wire_api, endpoint


def _comment_metadata(raw: str) -> Tuple[Optional[str], bool, bool, str]:
    name: Optional[str] = None
    supports_text = True
    supports_image = False
    command_lines: List[str] = []

    for line in raw.splitlines():
        stripped = line.strip()
        if stripped.startswith("#"):
            comment = stripped.lstrip("#").strip()
            if comment and name is None:
                left, _, right = comment.partition("|")
                if left.strip():
                    name = left.strip()
                supports = right or comment
                lower = supports.lower()
                if "supports" in lower:
                    supports_text = "text" in lower
                    supports_image = "image" in lower or "vision" in lower
            continue
        command_lines.append(line)

    return name, supports_text, supports_image, "\n".join(command_lines)


def _split_shell_tokens(command: str) -> List[str]:
    prepared = command.replace("\\\r\n", " ").replace("\\\n", " ")
    return shlex.split(prepared, comments=False, posix=True)


def _parse_json_body(raw: Optional[str]) -> Dict[str, Any]:
    if not raw:
        return {}
    candidates = [raw]
    try:
        candidates.append(raw.encode("utf-8").decode("unicode_escape"))
    except UnicodeDecodeError:
        pass
    for candidate in candidates:
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            continue
    return {}


def _derive_provider_name(base_url: str) -> str:
    host = urlparse(base_url).netloc.strip()
    if not host:
        return "第三方 API"
    return host[4:] if host.startswith("www.") else host


def _safe_excerpt(raw: bytes, *secrets: str, limit: int = 500) -> str:
    text = raw[:limit].decode("utf-8", errors="replace")
    for secret in secrets:
        if secret:
            text = text.replace(secret, mask_secret(secret))
    return text


def parse_api_curl(raw: str) -> ApiCredentialDraft:
    if not raw or not raw.strip():
        raise CredentialError("API 信息不能为空")

    hinted_name, supports_text, supports_image, command = _comment_metadata(raw)
    tokens = _split_shell_tokens(command)
    url: Optional[str] = None
    headers: List[str] = []
    data: Optional[str] = None

    index = 0
    while index < len(tokens):
        token = tokens[index]
        next_value = tokens[index + 1] if index + 1 < len(tokens) else None
        if token in {"--url", "-u"} and next_value is not None:
            url = next_value
            index += 2
            continue
        if token.startswith("--url="):
            url = token.split("=", 1)[1]
            index += 1
            continue
        if token in {"--header", "-H"} and next_value is not None:
            headers.append(next_value)
            index += 2
            continue
        if token.startswith("--header="):
            headers.append(token.split("=", 1)[1])
            index += 1
            continue
        if token in {"--data", "--data-raw", "--data-binary", "-d"} and next_value is not None:
            data = next_value
            index += 2
            continue
        if token.startswith("--data=") or token.startswith("--data-raw=") or token.startswith("--data-binary="):
            data = token.split("=", 1)[1]
            index += 1
            continue
        index += 1

    if not url:
        match = re.search(r"https?://[^\s'\"]+", command)
        if match:
            url = match.group(0)
    if not url:
        raise CredentialError("未能从 API 信息中解析 URL")

    api_key: Optional[str] = None
    for header in headers:
        match = re.search(r"^\s*authorization\s*:\s*bearer\s+(.+?)\s*$", header, re.IGNORECASE)
        if match:
            api_key = match.group(1).strip()
            break
    if not api_key:
        match = re.search(r"Authorization\s*:\s*Bearer\s+([^'\"\s]+)", raw, re.IGNORECASE)
        if match:
            api_key = match.group(1).strip()
    if not api_key:
        raise CredentialError("未能从 API 信息中解析 Authorization: Bearer API Key")
    if urlparse(api_key).scheme in {"http", "https"}:
        raise CredentialError("API Key 不能是 URL，请检查是否填反")

    api_base_url, wire_api, endpoint = _derive_base_url_and_wire_api(url)
    body = _parse_json_body(data)
    model = normalize_optional_string(body.get("model"))
    name = hinted_name or model or _derive_provider_name(api_base_url)

    return ApiCredentialDraft(
        name=name,
        api_key=api_key,
        api_base_url=api_base_url,
        api_endpoint=endpoint,
        wire_api=wire_api,
        default_model=model,
        supports_text=supports_text,
        supports_image=supports_image,
    )


def _credential_id(api_key: str, api_base_url: str, name: str) -> str:
    digest = hashlib.sha256(f"api_key\n{name}\n{api_base_url}\n{api_key}".encode("utf-8")).hexdigest()
    return f"cred_{digest[:16]}"


def _codex_auth_credential_id(auth_json: Dict[str, Any], name: str) -> str:
    canonical_auth = json.dumps(auth_json, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    digest = hashlib.sha256(f"codex_auth\n{name}\n{canonical_auth}".encode("utf-8")).hexdigest()
    return f"auth_{digest[:16]}"


def _store_path(path: Optional[Path] = None) -> Path:
    return (path or DEFAULT_STORE_PATH).expanduser()


def _empty_store() -> Dict[str, Any]:
    return {"version": STORE_VERSION, "current_credential_id": None, "credentials": []}


def load_store(store_path: Optional[Path] = None) -> Dict[str, Any]:
    path = _store_path(store_path)
    if not path.exists():
        return _empty_store()
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CredentialError(f"读取凭证库失败: {exc}") from exc
    if not isinstance(payload, dict):
        raise CredentialError("凭证库格式无效")
    payload.setdefault("version", STORE_VERSION)
    payload.setdefault("current_credential_id", None)
    credentials = payload.get("credentials")
    if not isinstance(credentials, list):
        payload["credentials"] = []
    return payload


def save_store(store: Dict[str, Any], store_path: Optional[Path] = None) -> None:
    path = _store_path(store_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = json.dumps(store, indent=2, ensure_ascii=False) + "\n"
    _write_text_atomic(path, content)


def _credentials_from_store(store: Dict[str, Any]) -> List[CodexCredential]:
    result = []
    for item in store.get("credentials", []):
        if isinstance(item, dict):
            cred = CodexCredential.from_dict(item)
            if cred.kind == "api_key" and cred.id and cred.api_key and cred.api_base_url:
                result.append(cred)
            elif cred.kind == "codex_auth" and cred.id and isinstance(cred.auth_json, dict):
                result.append(cred)
    return result


def list_credentials(store_path: Optional[Path] = None) -> List[Dict[str, Any]]:
    store = load_store(store_path)
    return [credential.to_summary_dict() for credential in _credentials_from_store(store)]


def add_api_credential(
    *,
    name: str,
    api_key: str,
    api_base_url: str,
    api_endpoint: Optional[str] = None,
    wire_api: Optional[str] = None,
    default_model: Optional[str] = None,
    supports_text: bool = True,
    supports_image: bool = False,
    store_path: Optional[Path] = None,
) -> CodexCredential:
    normalized_key = normalize_optional_string(api_key)
    if not normalized_key:
        raise CredentialError("API Key 不能为空")
    base_url, inferred_wire_api, endpoint_from_base = _derive_base_url_and_wire_api(api_base_url)
    endpoint = normalize_optional_string(api_endpoint) or endpoint_from_base
    selected_wire_api = normalize_wire_api(wire_api) or inferred_wire_api
    selected_name = normalize_optional_string(name) or _derive_provider_name(base_url)

    credential = CodexCredential(
        id=_credential_id(normalized_key, base_url, selected_name),
        name=selected_name,
        kind="api_key",
        api_key=normalized_key,
        api_base_url=base_url,
        api_endpoint=endpoint,
        wire_api=selected_wire_api,
        default_model=normalize_optional_string(default_model),
        supports_text=supports_text,
        supports_image=supports_image,
        created_at=utc_now(),
    )

    store = load_store(store_path)
    credentials = _credentials_from_store(store)
    replaced = False
    for index, existing in enumerate(credentials):
        if existing.id == credential.id:
            credential.created_at = existing.created_at
            credential.last_used_at = existing.last_used_at
            credential.liveness_status = existing.liveness_status
            credential.liveness_checked_at = existing.liveness_checked_at
            credential.liveness_message = existing.liveness_message
            credentials[index] = credential
            replaced = True
            break
    if not replaced:
        credentials.append(credential)
    store["credentials"] = [item.to_store_dict() for item in credentials]
    store["current_credential_id"] = credential.id
    save_store(store, store_path)
    return credential


def import_codex_auth_credential(
    source_codex_home: Path,
    *,
    store_path: Optional[Path] = None,
    name: Optional[str] = None,
) -> CodexCredential:
    source = source_codex_home.expanduser().resolve()
    auth_path = source / "auth.json"
    if not auth_path.exists():
        raise CredentialError(f"未找到 Codex AUTH 文件: {auth_path}")
    try:
        auth_json = json.loads(auth_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise CredentialError(f"读取 Codex AUTH 失败: {exc}") from exc
    if not isinstance(auth_json, dict) or not auth_json:
        raise CredentialError("Codex AUTH 文件格式无效")

    config_path = source / "config.toml"
    config_toml: Optional[str] = None
    if config_path.exists():
        try:
            config_toml = config_path.read_text(encoding="utf-8")
        except OSError:
            config_toml = None

    auth_mode = _detect_auth_mode(auth_json)
    selected_name = normalize_optional_string(name) or ("Codex AUTH" if auth_mode == "oauth" else "Codex 本机凭证")
    api_key = _extract_auth_api_key(auth_json) or ""
    credential = CodexCredential(
        id=_codex_auth_credential_id(auth_json, selected_name),
        name=selected_name,
        kind="codex_auth",
        api_key=api_key,
        api_base_url="",
        api_endpoint=None,
        wire_api=DEFAULT_WIRE_API,
        default_model=None,
        supports_text=True,
        supports_image=False,
        created_at=utc_now(),
        auth_json=auth_json,
        config_toml=config_toml,
        auth_mode=auth_mode,
        source_codex_home=str(source),
    )

    store = load_store(store_path)
    credentials = _credentials_from_store(store)
    replaced = False
    for index, existing in enumerate(credentials):
        if existing.id == credential.id:
            credential.created_at = existing.created_at
            credential.last_used_at = existing.last_used_at
            credential.liveness_status = existing.liveness_status
            credential.liveness_checked_at = existing.liveness_checked_at
            credential.liveness_message = existing.liveness_message
            credentials[index] = credential
            replaced = True
            break
    if not replaced:
        credentials.append(credential)
    store["credentials"] = [item.to_store_dict() for item in credentials]
    store["current_credential_id"] = credential.id
    save_store(store, store_path)
    return credential


def add_api_credential_from_curl(raw: str, store_path: Optional[Path] = None) -> CodexCredential:
    draft = parse_api_curl(raw)
    return add_api_credential(
        name=draft.name,
        api_key=draft.api_key,
        api_base_url=draft.api_base_url,
        api_endpoint=draft.api_endpoint,
        wire_api=draft.wire_api,
        default_model=draft.default_model,
        supports_text=draft.supports_text,
        supports_image=draft.supports_image,
        store_path=store_path,
    )


def login_gpt_auth_credential(
    *,
    codex_bin: Optional[Any] = None,
    login_root: Optional[Path] = None,
    store_path: Optional[Path] = None,
    name: Optional[str] = None,
    device_auth: bool = False,
    timeout: Optional[float] = None,
) -> Dict[str, Any]:
    target_root = (
        login_root.expanduser().resolve()
        if login_root is not None
        else (DEFAULT_STORE_PATH.parent / "auth-login" / datetime.now().strftime("%Y%m%d-%H%M%S")).expanduser().resolve()
    )
    target_root.mkdir(parents=True, exist_ok=True)

    selected_bin = str(codex_bin or _default_codex_bin())
    if selected_bin == "codex":
        selected_bin = _default_codex_bin()
    command = [selected_bin, "login"]
    if device_auth:
        command.append("--device-auth")
    env = os.environ.copy()
    env["CODEX_HOME"] = str(target_root)

    try:
        completed = subprocess.run(
            command,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError as exc:
        raise CredentialError(f"未找到 Codex CLI: {selected_bin}") from exc
    except subprocess.TimeoutExpired as exc:
        raise CredentialError("Gpt auth登录超时，请重新尝试。") from exc

    if completed.returncode != 0:
        combined = _safe_summary_text((completed.stderr or completed.stdout or "").strip())
        raise CredentialError(f"Gpt auth登录失败，退出码 {completed.returncode}: {combined}")

    auth_path = target_root / "auth.json"
    if not auth_path.exists():
        raise CredentialError(f"Gpt auth登录未生成 auth.json: {auth_path}")

    credential = import_codex_auth_credential(
        target_root,
        store_path=store_path,
        name=normalize_optional_string(name) or "Gpt auth登录",
    )
    return {
        "credential": credential.to_summary_dict(),
        "login_home": str(target_root),
        "message": f"已完成 Gpt auth登录，并保存凭证 {credential.name}。",
    }


def delete_credential(credential_id: str, store_path: Optional[Path] = None) -> Dict[str, Any]:
    store = load_store(store_path)
    before = _credentials_from_store(store)
    after = [item for item in before if item.id != credential_id]
    if len(after) == len(before):
        raise CredentialError(f"凭证不存在: {credential_id}")
    store["credentials"] = [item.to_store_dict() for item in after]
    if store.get("current_credential_id") == credential_id:
        store["current_credential_id"] = after[0].id if after else None
    save_store(store, store_path)
    return {"deleted": True, "credential_id": credential_id, "remaining": len(after)}


def _load_credential(credential_id: str, store_path: Optional[Path] = None) -> CodexCredential:
    for credential in _credentials_from_store(load_store(store_path)):
        if credential.id == credential_id:
            return credential
    raise CredentialError(f"凭证不存在: {credential_id}")


def _default_codex_bin() -> str:
    found = shutil.which("codex")
    if found:
        return found
    candidates = [
        Path.home() / ".local" / "bin" / "codex",
        Path("/opt/homebrew/bin/codex"),
        Path("/usr/local/bin/codex"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return "codex"


def _set_credential_liveness(
    credential_id: str,
    *,
    status: str,
    message: str,
    store_path: Optional[Path] = None,
) -> CodexCredential:
    store = load_store(store_path)
    credentials = _credentials_from_store(store)
    updated: Optional[CodexCredential] = None
    for item in credentials:
        if item.id == credential_id:
            item.liveness_status = normalize_liveness_status(status)
            item.liveness_checked_at = utc_now()
            item.liveness_message = _safe_summary_text(message)
            updated = item
            break
    if updated is None:
        raise CredentialError(f"凭证不存在: {credential_id}")
    store["credentials"] = [item.to_store_dict() for item in credentials]
    save_store(store, store_path)
    return updated


def _safe_summary_text(value: str, *secrets: str, limit: int = 240) -> str:
    text = str(value or "").strip().replace("\n", " ")
    for secret in secrets:
        if secret:
            text = text.replace(secret, mask_secret(secret))
    return text[:limit]


def _write_text_atomic(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}")
    tmp.write_text(content, encoding="utf-8")
    os.replace(tmp, path)


def _backup_auth_and_config(codex_home: Path) -> Path:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_dir = codex_home / "backups" / f"credential-launch-{stamp}"
    suffix = 0
    while backup_dir.exists():
        suffix += 1
        backup_dir = codex_home / "backups" / f"credential-launch-{stamp}-{suffix}"
    backup_dir.mkdir(parents=True, exist_ok=False)
    for name in ("auth.json", "config.toml"):
        src = codex_home / name
        if src.exists():
            shutil.copy2(src, backup_dir / name)
    return backup_dir


def _write_api_auth_json(codex_home: Path, credential: CodexCredential) -> Path:
    path = codex_home / "auth.json"
    content = json.dumps(
        {"auth_mode": API_KEY_AUTH_MODE, "OPENAI_API_KEY": credential.api_key},
        indent=2,
        ensure_ascii=False,
    ) + "\n"
    _write_text_atomic(path, content)
    return path


def _write_codex_auth_json(codex_home: Path, credential: CodexCredential) -> Path:
    if not isinstance(credential.auth_json, dict) or not credential.auth_json:
        raise CredentialError("Codex AUTH 凭证缺少 auth.json 内容")
    path = codex_home / "auth.json"
    content = json.dumps(credential.auth_json, indent=2, ensure_ascii=False) + "\n"
    _write_text_atomic(path, content)
    return path


def _without_managed_config(content: str, remove_model: bool) -> List[str]:
    lines = content.splitlines()
    result: List[str] = []
    current_table: Optional[str] = None
    skipping_managed_provider = False

    for line in lines:
        stripped = line.strip()
        table_match = re.match(r"^\[([^\]]+)\]\s*$", stripped)
        if table_match:
            table_name = table_match.group(1).strip()
            if table_name == f"model_providers.{MANAGED_PROVIDER_ID}":
                skipping_managed_provider = True
                current_table = table_name
                continue
            skipping_managed_provider = False
            current_table = table_name

        if skipping_managed_provider:
            continue

        if current_table is None:
            if re.match(r"^\s*model_provider\s*=", line):
                continue
            if remove_model and re.match(r"^\s*model\s*=", line):
                continue
        result.append(line)

    return result


def _merge_config_toml(existing: str, credential: CodexCredential) -> str:
    lines = _without_managed_config(existing, remove_model=credential.default_model is not None)
    top_lines: List[str] = []
    if credential.default_model:
        top_lines.append(f"model = {_toml_quote(credential.default_model)}")
    top_lines.append(f"model_provider = {_toml_quote(MANAGED_PROVIDER_ID)}")

    first_table_index = next(
        (idx for idx, line in enumerate(lines) if re.match(r"^\s*\[[^\]]+\]\s*$", line.strip())),
        len(lines),
    )
    prefix = lines[:first_table_index]
    suffix = lines[first_table_index:]
    while prefix and not prefix[-1].strip():
        prefix.pop()
    while suffix and not suffix[0].strip():
        suffix.pop(0)

    merged: List[str] = []
    merged.extend(prefix)
    if merged:
        merged.append("")
    merged.extend(top_lines)
    if suffix:
        merged.append("")
        merged.extend(suffix)

    provider_name = credential.name or _derive_provider_name(credential.api_base_url)
    provider_block = [
        "",
        f"[model_providers.{MANAGED_PROVIDER_ID}]",
        f"name = {_toml_quote(provider_name)}",
        f"base_url = {_toml_quote(credential.api_base_url)}",
        f"wire_api = {_toml_quote(credential.wire_api or DEFAULT_WIRE_API)}",
        "requires_openai_auth = true",
        f"experimental_bearer_token = {_toml_quote(credential.api_key)}",
        "supports_websockets = false",
    ]
    merged.extend(provider_block)
    return "\n".join(merged).strip() + "\n"


def _write_config_toml(codex_home: Path, credential: CodexCredential) -> Path:
    path = codex_home / "config.toml"
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    _write_text_atomic(path, _merge_config_toml(existing, credential))
    return path


def _merge_auth_config_toml(existing: str) -> str:
    lines = _without_managed_config(existing, remove_model=False)
    top_lines = ['model_provider = "openai"']

    first_table_index = next(
        (idx for idx, line in enumerate(lines) if re.match(r"^\s*\[[^\]]+\]\s*$", line.strip())),
        len(lines),
    )
    prefix = lines[:first_table_index]
    suffix = lines[first_table_index:]
    while prefix and not prefix[-1].strip():
        prefix.pop()
    while suffix and not suffix[0].strip():
        suffix.pop(0)

    merged: List[str] = []
    merged.extend(prefix)
    if merged:
        merged.append("")
    merged.extend(top_lines)
    if suffix:
        merged.append("")
        merged.extend(suffix)
    return "\n".join(merged).strip() + "\n"


def _write_auth_config_toml(codex_home: Path) -> Path:
    path = codex_home / "config.toml"
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    _write_text_atomic(path, _merge_auth_config_toml(existing))
    return path


def _restart_codex_app() -> bool:
    if sys_platform() != "darwin":
        return False
    subprocess.run(
        ["osascript", "-e", 'tell application id "com.openai.codex" to quit'],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=5,
        check=False,
    )
    try:
        subprocess.run(["open", "-b", "com.openai.codex"], check=True, timeout=10)
        return True
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        fallback = Path("/Applications/Codex.app")
        if fallback.exists():
            subprocess.run(["open", str(fallback)], check=False, timeout=10)
            return True
    return False


def sys_platform() -> str:
    import sys

    return sys.platform


def launch_credential(
    credential_id: str,
    *,
    codex_home: Path,
    store_path: Optional[Path] = None,
    restart: bool = True,
) -> Dict[str, Any]:
    credential = _load_credential(credential_id, store_path)
    target = codex_home.expanduser().resolve()
    target.mkdir(parents=True, exist_ok=True)
    backup_dir = _backup_auth_and_config(target)
    if credential.kind == "api_key":
        auth_path = _write_api_auth_json(target, credential)
        config_path = _write_config_toml(target, credential)
    elif credential.kind == "codex_auth":
        auth_path = _write_codex_auth_json(target, credential)
        config_path = _write_auth_config_toml(target)
    else:
        raise CredentialError(f"不支持的凭证类型: {credential.kind}")
    restarted = _restart_codex_app() if restart else False

    store = load_store(store_path)
    credentials = _credentials_from_store(store)
    for item in credentials:
        if item.id == credential.id:
            item.last_used_at = utc_now()
            credential = item
            break
    store["credentials"] = [item.to_store_dict() for item in credentials]
    store["current_credential_id"] = credential.id
    save_store(store, store_path)

    return {
        "credential": credential.to_summary_dict(),
        "target_home": str(target),
        "auth_path": str(auth_path),
        "config_path": str(config_path),
        "backup_dir": str(backup_dir),
        "restarted": restarted,
        "message": f"已用凭证 {credential.name} 写入 Codex 配置" + ("并启动 Codex。" if restarted else "。"),
    }


def _validation_endpoint(credential: CodexCredential) -> str:
    if credential.api_endpoint:
        return credential.api_endpoint
    base = credential.api_base_url.rstrip("/")
    if credential.wire_api == CHAT_COMPLETIONS_WIRE_API:
        return f"{base}/chat/completions"
    return f"{base}/responses"


def _validation_body(credential: CodexCredential) -> Dict[str, Any]:
    model = normalize_optional_string(credential.default_model)
    if not model:
        raise CredentialError("API 凭证缺少默认模型，无法验活")
    if credential.wire_api == CHAT_COMPLETIONS_WIRE_API:
        return {
            "model": model,
            "messages": [{"role": "user", "content": "Say ok."}],
            "stream": False,
        }
    return {
        "model": model,
        "input": "Say ok.",
    }


def _finalize_validation_result(
    credential: CodexCredential,
    result: Dict[str, Any],
    *,
    store_path: Optional[Path] = None,
) -> Dict[str, Any]:
    status = LIVENESS_ALIVE if result.get("ok") else LIVENESS_DEAD
    message = str(result.get("message") or result.get("reason") or "")
    updated = _set_credential_liveness(
        credential.id,
        status=status,
        message=message,
        store_path=store_path,
    )
    result["credential"] = updated.to_summary_dict()
    return result


def _validate_codex_auth_credential(
    credential: CodexCredential,
    *,
    store_path: Optional[Path],
    timeout: float,
    codex_bin: Optional[Any],
) -> Dict[str, Any]:
    if not isinstance(credential.auth_json, dict) or not credential.auth_json:
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "missing_auth_json",
                "credential": credential.to_summary_dict(),
                "message": "AUTH 凭证缺少 auth.json 内容。",
            },
            store_path=store_path,
        )

    selected_bin = str(codex_bin or _default_codex_bin())
    if selected_bin == "codex":
        selected_bin = _default_codex_bin()
    with tempfile.TemporaryDirectory() as tmp:
        home = Path(tmp)
        _write_text_atomic(home / "auth.json", json.dumps(credential.auth_json, indent=2, ensure_ascii=False) + "\n")
        if credential.config_toml:
            _write_text_atomic(home / "config.toml", credential.config_toml)
        env = os.environ.copy()
        env["CODEX_HOME"] = str(home)
        started = datetime.now(timezone.utc)
        try:
            completed = subprocess.run(
                [selected_bin, "login", "status"],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=max(float(timeout), 0.1),
                check=False,
            )
            elapsed_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
            ok = completed.returncode == 0
            message = "AUTH 凭证存活。" if ok else "AUTH 凭证已失效。"
            return _finalize_validation_result(
                credential,
                {
                    "ok": ok,
                    "reason": "ok" if ok else "login_status_failed",
                    "credential": credential.to_summary_dict(),
                    "elapsed_ms": elapsed_ms,
                    "message": message,
                    "error_excerpt": _safe_summary_text(completed.stderr or completed.stdout or ""),
                },
                store_path=store_path,
            )
        except FileNotFoundError:
            return _finalize_validation_result(
                credential,
                {
                    "ok": False,
                    "reason": "codex_not_found",
                    "credential": credential.to_summary_dict(),
                    "message": "未找到 Codex CLI，无法验证 AUTH 凭证。",
                },
                store_path=store_path,
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            return _finalize_validation_result(
                credential,
                {
                    "ok": False,
                    "reason": "login_status_error",
                    "credential": credential.to_summary_dict(),
                    "message": "AUTH 凭证验活失败。",
                    "error_excerpt": _safe_summary_text(str(exc)),
                },
                store_path=store_path,
            )


def validate_credential(
    credential_id: str,
    *,
    store_path: Optional[Path] = None,
    timeout: float = 10,
    codex_bin: Optional[Any] = None,
) -> Dict[str, Any]:
    credential = _load_credential(credential_id, store_path)
    if credential.kind == "codex_auth":
        return _validate_codex_auth_credential(credential, store_path=store_path, timeout=timeout, codex_bin=codex_bin)
    if credential.kind != "api_key":
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "unsupported_credential_type",
                "credential": credential.to_summary_dict(),
                "message": "不支持的凭证类型。",
            },
            store_path=store_path,
        )
    if not credential.api_key:
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "missing_api_key",
                "credential": credential.to_summary_dict(),
                "message": "API 凭证缺少 API Key。",
            },
            store_path=store_path,
        )

    endpoint = _validation_endpoint(credential)
    try:
        body = _validation_body(credential)
    except CredentialError as exc:
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "missing_model",
                "credential": credential.to_summary_dict(),
                "endpoint": endpoint,
                "wire_api": credential.wire_api,
                "message": str(exc),
            },
            store_path=store_path,
        )

    request = Request(
        endpoint,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {credential.api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        },
        method="POST",
    )

    started = datetime.now(timezone.utc)
    try:
        with urlopen(request, timeout=max(float(timeout), 0.1)) as response:
            response.read(4096)
            elapsed_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
            status_code = int(getattr(response, "status", 200))
            ok = 200 <= status_code < 300
            return _finalize_validation_result(
                credential,
                {
                    "ok": ok,
                    "reason": "ok" if ok else "http_error",
                    "credential": credential.to_summary_dict(),
                    "endpoint": endpoint,
                    "wire_api": credential.wire_api,
                    "status_code": status_code,
                    "elapsed_ms": elapsed_ms,
                    "message": "API 凭证存活。" if ok else f"API 凭证已失效，HTTP {status_code}。",
                },
                store_path=store_path,
            )
    except HTTPError as exc:
        body = exc.read(4096)
        elapsed_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "http_error",
                "credential": credential.to_summary_dict(),
                "endpoint": endpoint,
                "wire_api": credential.wire_api,
                "status_code": int(exc.code),
                "elapsed_ms": elapsed_ms,
                "error_excerpt": _safe_excerpt(body, credential.api_key),
                "message": f"API 凭证已失效，HTTP {exc.code}。",
            },
            store_path=store_path,
        )
    except URLError as exc:
        elapsed_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "network_error",
                "credential": credential.to_summary_dict(),
                "endpoint": endpoint,
                "wire_api": credential.wire_api,
                "elapsed_ms": elapsed_ms,
                "error_excerpt": _safe_excerpt(str(exc.reason).encode("utf-8"), credential.api_key),
                "message": "API 凭证已失效，无法连接服务。",
            },
            store_path=store_path,
        )
    except (TimeoutError, OSError) as exc:
        elapsed_ms = int((datetime.now(timezone.utc) - started).total_seconds() * 1000)
        return _finalize_validation_result(
            credential,
            {
                "ok": False,
                "reason": "network_error",
                "credential": credential.to_summary_dict(),
                "endpoint": endpoint,
                "wire_api": credential.wire_api,
                "elapsed_ms": elapsed_ms,
                "error_excerpt": _safe_excerpt(str(exc).encode("utf-8"), credential.api_key),
                "message": "API 凭证已失效，网络请求异常。",
            },
            store_path=store_path,
        )


def validate_all_credentials(
    *,
    store_path: Optional[Path] = None,
    timeout: float = 10,
    codex_bin: Optional[Any] = None,
) -> Dict[str, Any]:
    credentials = _credentials_from_store(load_store(store_path))
    results: List[Dict[str, Any]] = []
    for credential in credentials:
        results.append(validate_credential(credential.id, store_path=store_path, timeout=timeout, codex_bin=codex_bin))
    summaries = list_credentials(store_path=store_path)
    alive = sum(1 for item in summaries if item.get("liveness_status") == LIVENESS_ALIVE)
    dead = sum(1 for item in summaries if item.get("liveness_status") == LIVENESS_DEAD)
    unknown = sum(1 for item in summaries if item.get("liveness_status") == LIVENESS_UNKNOWN)
    return {
        "validated": len(results),
        "alive": alive,
        "dead": dead,
        "unknown": unknown,
        "credentials": summaries,
        "results": results,
        "message": f"验活完成：{alive} 个存活，{dead} 个已失效。",
    }
